-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: youtube
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reply` (
  `r_no` int NOT NULL AUTO_INCREMENT,
  `m_no` int NOT NULL,
  `v_no` int NOT NULL,
  `c_no` int NOT NULL,
  `r_contents` varchar(1000) DEFAULT NULL,
  `r_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`r_no`),
  KEY `e21e1_idx` (`m_no`),
  KEY `eqw123_idx` (`v_no`),
  KEY `e123_idx` (`c_no`),
  CONSTRAINT `e123` FOREIGN KEY (`c_no`) REFERENCES `channel` (`c_no`),
  CONSTRAINT `e21e1` FOREIGN KEY (`m_no`) REFERENCES `member` (`m_no`),
  CONSTRAINT `eqw123` FOREIGN KEY (`v_no`) REFERENCES `video` (`v_no`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply`
--

LOCK TABLES `reply` WRITE;
/*!40000 ALTER TABLE `reply` DISABLE KEYS */;
INSERT INTO `reply` VALUES (8,2,2,2,'dfg','2021-12-29 05:21:10'),(13,1,3,1,'z\n','2021-12-29 05:48:27'),(14,5,6,3,'as','2021-12-29 09:50:43'),(17,1,5,1,'sdfsdf','2021-12-30 07:55:02'),(18,1,4,2,'zzzz','2021-12-30 07:55:51'),(19,1,2,1,'a','2021-12-30 08:03:04'),(20,6,2,1,'zzz','2021-12-30 08:03:49'),(21,6,5,1,'zz','2021-12-30 08:03:57'),(22,1,3,1,'a','2021-12-30 09:52:29'),(23,1,4,2,'zxczxc','2021-12-30 09:52:38');
/*!40000 ALTER TABLE `reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  9:37:02
