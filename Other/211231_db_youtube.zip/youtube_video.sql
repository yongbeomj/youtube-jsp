-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: youtube
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `v_no` int NOT NULL AUTO_INCREMENT,
  `v_thumbnail` varchar(100) NOT NULL,
  `v_filename` varchar(100) NOT NULL,
  `v_title` varchar(100) NOT NULL,
  `v_coments` varchar(5000) NOT NULL,
  `v_createdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `v_updatedate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `m_no` int NOT NULL,
  `v_path` varchar(300) NOT NULL,
  PRIMARY KEY (`v_no`),
  KEY `m_no` (`m_no`),
  CONSTRAINT `video_ibfk_1` FOREIGN KEY (`m_no`) REFERENCES `member` (`m_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (2,'9.jpg_1','Globe - 989803.mp4_1','눈이 내린다?!','zzzz','2021-12-26 06:00:50','2021-12-26 06:00:50',1,'C:\\Users\\강보균\\Desktop\\AJSP\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\강보균\\web\\upload'),(3,'9.jpg_1','Seoul.mp4_1','영상2','asd','2021-12-29 03:17:07','2021-12-29 03:17:07',1,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(4,'11.jpg_2','Seoul1.mp4_2','영상3','ㅁㄴㅇ','2021-12-29 03:18:47','2021-12-29 03:18:47',2,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(5,'3.jpg_1','Seoul2.mp4_1','sample','asd','2021-12-29 03:57:34','2021-12-29 03:57:34',1,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(6,'10.jpg_5','이젠 컴퓨터 화면구현테스트 최병호 - Chrome 2021-12-17 15-17-07.mp4_5','게시물 구현테스트 ','게시물 구현테스트','2021-12-29 09:29:22','2021-12-29 09:29:22',5,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(7,'null_11','이젠 컴퓨터 화면구현테스트 최병호 - Chrome 2021-12-17 15-17-071.mp4_11','asdfdsa','sadfasd','2021-12-31 07:06:17','2021-12-31 07:06:17',11,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(8,'이젠 컴퓨터 화면구현테스트 최병호 - Chrome 2021-12-17 15-17-072.mp4_11','11png.png_11','테스트1','테스트입니다','2021-12-31 07:07:45','2021-12-31 07:07:45',11,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(9,'강호동.png_9','연예계 싸움 서열 정리하는 강호동│KBS 151006 방송.mp4_9','강호동 대박;;','강호동이 힘자랑하는 영상','2021-12-31 07:07:54','2021-12-31 07:07:54',9,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(10,'어쩔티비.jpg_9','SNL 코리아 시즌2 신혜선 하이라이트 - 서른이지만 열일곱ㅣ SNL 코리아 하이라이트 - 쿠팡플레이 오리지널 - 쿠팡.mp4_9','신혜선 완전 10대자너 ㅋㅋ','ㄹㅇㅋㅋ ㅇㅈ? ㅇㅇㅈ\r\n동의? 어보감~','2021-12-31 07:08:58','2021-12-31 07:08:58',9,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(11,'캡처.PNG_10','freekicks.mp4_10','usually freekicks, increadble!','freekick','2021-12-31 07:10:10','2021-12-31 07:10:10',10,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(12,'집만들기.jpg_9','Restoration Old Ｎｉｎｔenｄｏ gameboy advance - Restoring Game Boy Advance ＧＢＡ.mp4_9','따위가 아니라 ㄹㅇ 만들어버림','이런 금손들은 유튜브로 돈벌자너','2021-12-31 07:10:19','2021-12-31 07:10:19',9,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(13,'성룡.jfif_9','전설이 된 맞대결! 영화 속 최고의 1대1 무술격투씬 (1부).mp4_9','성룡은 ㄹㅇ 전설이다','가슴이 웅장해진다','2021-12-31 07:10:57','2021-12-31 07:10:57',9,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(14,'캡처2.PNG_10','Building complete and warm survival shelter.mp4_10','Building complete and warm survival shelter','building with survivors','2021-12-31 07:11:20','2021-12-31 07:11:20',10,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(15,'케플러.jpg_9','Kep1er 케플러  ‘WA DA DA’  MV Teaser #1.mp4_9','걸그룹 춤춘다','우왕ㅋ굳ㅋ','2021-12-31 07:11:35','2021-12-31 07:11:35',9,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(16,'타이슨.jpg_9','Mike Tyson.mp4_9','한대에 세명','샷건소리가 나넼ㅋㅋㅋ','2021-12-31 07:12:35','2021-12-31 07:12:35',9,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31 17:45:14
