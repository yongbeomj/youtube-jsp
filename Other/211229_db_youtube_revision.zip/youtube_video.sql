-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: youtube
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `v_no` int NOT NULL AUTO_INCREMENT,
  `v_thumbnail` varchar(100) NOT NULL,
  `v_filename` varchar(100) NOT NULL,
  `v_title` varchar(100) NOT NULL,
  `v_coments` varchar(5000) NOT NULL,
  `v_createdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `v_updatedate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `m_no` int NOT NULL,
  `v_path` varchar(300) NOT NULL,
  PRIMARY KEY (`v_no`),
  KEY `m_no` (`m_no`),
  CONSTRAINT `video_ibfk_1` FOREIGN KEY (`m_no`) REFERENCES `member` (`m_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (2,'9.jpg_1','Globe - 989803.mp4_1','눈이 내린다?!','zzzz','2021-12-26 06:00:50','2021-12-26 06:00:50',1,'C:\\Users\\강보균\\Desktop\\AJSP\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\강보균\\web\\upload'),(3,'9.jpg_1','Seoul.mp4_1','영상2','asd','2021-12-29 03:17:07','2021-12-29 03:17:07',1,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(4,'null_2','Seoul1.mp4_2','영상3','ㅁㄴㅇ','2021-12-29 03:18:47','2021-12-29 03:18:47',2,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(5,'5.jpg_1','Seoul2.mp4_1','sample','asd','2021-12-29 03:57:34','2021-12-29 03:57:34',1,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload'),(6,'5d6fc8a93b00009605ccb83b.jpeg_5','이젠 컴퓨터 화면구현테스트 최병호 - Chrome 2021-12-17 15-17-07.mp4_5','게시물 구현테스트 ','게시물 구현테스트','2021-12-29 09:29:22','2021-12-29 09:29:22',5,'D:\\eclipse-workspace-jyb\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Youtube\\website\\upload');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-29 21:30:57
